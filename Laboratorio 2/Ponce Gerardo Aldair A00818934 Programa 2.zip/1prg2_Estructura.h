#ifndef ESTRUCTURA_H
#define ESTRUCTURA_H

#include <iostream>
#include <string>

using namespace std;


struct estructura {
  string nombreClase;
  int lineasBases;
  int lineasBorradas;
  int lineasModificadas;
  int lineasAgregadas;
  int lineasTotales;
  int items;
  string tipo;
};

#endif
